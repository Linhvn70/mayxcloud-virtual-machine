#!/usr/bin/env python3
"""MXVM build script.
  python build.py --windows | --linux | --all  [--source SRC.zip] [--package-only]
Outputs go to ./release/ and are verified (exist, not empty).
"""
from __future__ import annotations
import argparse, os, platform, shutil, struct, subprocess, sys, zipfile, zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERSION = (ROOT / "VERSION").read_text().strip() if (ROOT / "VERSION").exists() else "0.1.0"
APP_ID = "MayXCloudVM"
BRAND = "MâyXCloudVirtualMachine"
RELEASE = ROOT / "release"
MIN_SIZE = 100 * 1024  # an installer under 100 KB is considered broken


def run(cmd, **kw):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True, **kw)


def extract_source(zip_path: str | None) -> Path:
    """Extract a source ZIP (if given or found in repo root) and return the project dir."""
    z = Path(zip_path) if zip_path else next(
        (p for p in ROOT.glob("*.zip") if "mayxcloud" in p.name.lower()), None)
    if not z:
        return ROOT
    out = ROOT / "build" / "src"
    shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True)
    with zipfile.ZipFile(z) as zf:
        zf.extractall(out)
    mains = list(out.rglob("main.py"))
    if not mains:
        sys.exit(f"ERROR: no main.py inside {z}")
    print(f"Source extracted from {z} -> {mains[0].parent}")
    return mains[0].parent


def install_deps(src: Path):
    req = src / "requirements.txt"
    if req.exists():
        run([sys.executable, "-m", "pip", "install", "-r", req])
    run([sys.executable, "-m", "pip", "install", "pyinstaller"])


def pyinstaller(src: Path) -> Path:
    dist, work = ROOT / "build" / "dist", ROOT / "build" / "work"
    shutil.rmtree(dist, ignore_errors=True)
    run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--windowed",
         "--name", APP_ID, "--distpath", dist, "--workpath", work,
         "--specpath", ROOT / "build", "--paths", src, src / "main.py"])
    app = dist / APP_ID
    if not app.is_dir():
        sys.exit("ERROR: PyInstaller produced no output")
    return app


def make_png(path: Path, size=256):
    """Minimal solid-blue PNG placeholder icon (no external deps)."""
    row = b"\x00" + bytes([0x1E, 0x6F, 0xD9]) * size
    raw = zlib.compress(row * size)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xFFFFFFFF)
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0))
                     + chunk(b"IDAT", raw) + chunk(b"IEND", b""))


def verify(files: list[Path]):
    ok = True
    for f in files:
        if not f.is_file():
            print(f"FAIL missing: {f}"); ok = False
        elif f.stat().st_size < MIN_SIZE:
            print(f"FAIL too small ({f.stat().st_size} B): {f}"); ok = False
        else:
            print(f"OK   {f.name}  {f.stat().st_size / 1e6:.1f} MB")
    if not ok:
        sys.exit(1)


# ---------------- Windows ----------------
def build_windows(app: Path, src: Path) -> Path:
    iscc = shutil.which("iscc") or shutil.which("ISCC.exe")
    if not iscc:
        for p in (r"C:\Program Files (x86)\Inno Setup 6\ISCC.exe", r"C:\Program Files\Inno Setup 6\ISCC.exe"):
            if os.path.exists(p):
                iscc = p
    if not iscc:
        sys.exit("ERROR: Inno Setup (iscc) not found")
    qemu = ROOT / "installer" / "windows" / "qemu"
    args = [iscc, f"/DAppVersion={VERSION}", f"/DSourceDir={app}", f"/DOutputDir={RELEASE}"]
    if qemu.is_dir() and any(qemu.iterdir()):
        args.append(f"/DQemuDir={qemu}")
    else:
        print("WARNING: no bundled QEMU in installer/windows/qemu; installer will require QEMU on the host")
    run(args + [ROOT / "installer" / "windows" / "mxvm.iss"])
    return RELEASE / f"{BRAND}_Setup.exe"


# ---------------- Linux ----------------
def build_deb(app: Path) -> Path:
    pkg = ROOT / "build" / "deb"
    shutil.rmtree(pkg, ignore_errors=True)
    (pkg / "DEBIAN").mkdir(parents=True)
    opt = pkg / "opt" / "mayxcloud-vm"
    shutil.copytree(app, opt)
    (pkg / "usr/bin").mkdir(parents=True)
    (pkg / "usr/bin/mayxcloud-vm").symlink_to(f"/opt/mayxcloud-vm/{APP_ID}")
    (pkg / "usr/share/applications").mkdir(parents=True)
    (pkg / "usr/share/applications/mayxcloud-vm.desktop").write_text(
        "[Desktop Entry]\nType=Application\nName=MâyXCloud Virtual Machine\n"
        "Exec=/usr/bin/mayxcloud-vm\nIcon=mayxcloud-vm\nCategories=System;Emulator;\nTerminal=false\n")
    (pkg / "usr/share/icons/hicolor/256x256/apps").mkdir(parents=True)
    make_png(pkg / "usr/share/icons/hicolor/256x256/apps/mayxcloud-vm.png")
    size_kb = sum(f.stat().st_size for f in opt.rglob("*") if f.is_file()) // 1024
    (pkg / "DEBIAN/control").write_text(
        f"Package: mayxcloud-vm\nVersion: {VERSION}\nSection: utils\nPriority: optional\n"
        f"Architecture: amd64\nInstalled-Size: {size_kb}\n"
        "Depends: qemu-system-x86, qemu-utils, ovmf, libgl1, libxcb-cursor0, libxkbcommon-x11-0\n"
        "Recommends: qemu-system-arm, qemu-system-misc, qemu-system-ppc, spice-client-gtk\n"
        "Maintainer: MâyXCloud <noreply@example.com>\n"
        "Description: MâyXCloud Virtual Machine (MXVM)\n Desktop virtualization manager based on QEMU/KVM.\n")
    # Uninstall (dpkg -r) removes /opt files; VM data lives in the user's home and is never touched.
    out = RELEASE / f"{BRAND}.deb"
    run(["dpkg-deb", "--root-owner-group", "--build", pkg, out])
    return out


def build_appimage(app: Path) -> Path:
    tool = os.environ.get("APPIMAGETOOL") or shutil.which("appimagetool")
    if not tool:
        sys.exit("ERROR: appimagetool not found (set APPIMAGETOOL)")
    ad = ROOT / "build" / "AppDir"
    shutil.rmtree(ad, ignore_errors=True)
    shutil.copytree(app, ad / "usr" / "lib" / "mxvm")
    make_png(ad / "mayxcloud-vm.png")
    (ad / "mayxcloud-vm.desktop").write_text(
        "[Desktop Entry]\nType=Application\nName=MâyXCloud Virtual Machine\n"
        f"Exec={APP_ID}\nIcon=mayxcloud-vm\nCategories=System;Emulator;\nTerminal=false\n")
    apprun = ad / "AppRun"
    apprun.write_text('#!/bin/sh\nHERE="$(dirname "$(readlink -f "$0")")"\n'
                      f'exec "$HERE/usr/lib/mxvm/{APP_ID}" "$@"\n')
    apprun.chmod(0o755)
    out = RELEASE / f"{BRAND}.AppImage"
    env = dict(os.environ, ARCH="x86_64", APPIMAGE_EXTRACT_AND_RUN="1")
    run([tool, ad, out], env=env)
    out.chmod(0o755)
    return out


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--windows", action="store_true")
    g.add_argument("--linux", action="store_true")
    g.add_argument("--all", action="store_true")
    ap.add_argument("--source", help="source ZIP to extract (auto-detected if present in repo root)")
    ap.add_argument("--package-only", action="store_true", help="skip pip/PyInstaller; reuse build/dist")
    a = ap.parse_args()
    system = platform.system()
    do_win, do_lin = a.windows or a.all, a.linux or a.all
    if do_win and system != "Windows":
        sys.exit("ERROR: Windows installer must be built on Windows (use the GitHub Actions windows job)")
    if do_lin and system != "Linux":
        sys.exit("ERROR: Linux packages must be built on Linux (use the GitHub Actions linux job)")
    RELEASE.mkdir(exist_ok=True)
    src = extract_source(a.source)
    if a.package_only:
        app = ROOT / "build" / "dist" / APP_ID
    else:
        install_deps(src)
        app = pyinstaller(src)
    outs = []
    if do_win:
        outs.append(build_windows(app, src))
    if do_lin:
        outs.append(build_deb(app))
        outs.append(build_appimage(app))
    verify(outs)
    print("Build OK")


if __name__ == "__main__":
    main()
