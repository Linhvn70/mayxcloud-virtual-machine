import sys, traceback, datetime


def _log(text: str):
    try:
        from core.sysinfo import data_dir
        with open(data_dir() / "mxvm.log", "a", encoding="utf-8") as f:
            f.write(f"[{datetime.datetime.now():%Y-%m-%d %H:%M:%S}] {text}\n")
    except Exception:
        pass


def main():
    from PySide6.QtWidgets import QApplication, QMessageBox
    app = QApplication(sys.argv)

    def hook(et, ev, tb):
        msg = "".join(traceback.format_exception(et, ev, tb))
        _log(msg)
        QMessageBox.critical(None, "MXVM error", msg[-1500:])
    sys.excepthook = hook

    from ui.main_window import MainWindow
    w = MainWindow()
    w.show()
    _log("Application started")
    sys.exit(app.exec())


if __name__ == "__main__":
    try:
        main()
    except Exception:
        _log(traceback.format_exc())
        raise
