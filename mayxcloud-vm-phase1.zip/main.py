from core.host_detect import detect_host, choose_accel

if __name__ == "__main__":
    h = detect_host()
    accel, why = choose_accel(h)
    print(h)
    print(f"accel={accel} ({why})")
