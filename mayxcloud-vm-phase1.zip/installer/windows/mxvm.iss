; MâyXCloud Virtual Machine - Inno Setup script (Unicode, Inno Setup 6+)
#ifndef AppVersion
  #define AppVersion "0.1.0"
#endif
#ifndef SourceDir
  #error SourceDir not defined
#endif
#ifndef OutputDir
  #define OutputDir "..\..\release"
#endif

[Setup]
AppId={{8F3B6D2A-5C41-4E7B-9A0D-1F2E3D4C5B6A}
AppName=MâyXCloud Virtual Machine
AppVersion={#AppVersion}
AppPublisher=MâyXCloud
DefaultDirName={autopf}\MayXCloudVM
DefaultGroupName=MâyXCloud Virtual Machine
UninstallDisplayName=MâyXCloud Virtual Machine
UninstallDisplayIcon={app}\MayXCloudVM.exe
OutputDir={#OutputDir}
OutputBaseFilename=MâyXCloudVirtualMachine_Setup
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
PrivilegesRequired=admin
; Same AppId => updates install over the old version.

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
#ifdef QemuDir
Source: "{#QemuDir}\*"; DestDir: "{app}\qemu"; Flags: recursesubdirs createallsubdirs ignoreversion
#endif

[Icons]
Name: "{group}\MâyXCloud Virtual Machine"; Filename: "{app}\MayXCloudVM.exe"
Name: "{group}\Uninstall MâyXCloud Virtual Machine"; Filename: "{uninstallexe}"
Name: "{autodesktop}\MâyXCloud Virtual Machine"; Filename: "{app}\MayXCloudVM.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\MayXCloudVM.exe"; Description: "Launch MâyXCloud Virtual Machine"; Flags: nowait postinstall skipifsilent

; VM data is stored in the user profile (never in {app}); uninstall and update do not delete it.

[Code]
function InitializeSetup(): Boolean;
begin
  Result := True;
  if not IsWin64 then begin
    MsgBox('MâyXCloud Virtual Machine requires 64-bit Windows.', mbError, MB_OK);
    Result := False;
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssDone then
    Log('Install finished. Windows Hypervisor Platform is checked by the app at runtime and is not changed by the installer.');
end;
