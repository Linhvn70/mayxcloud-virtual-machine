import sys, os, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core import sysinfo

class T(unittest.TestCase):
    def test_snapshot(self):
        s = sysinfo.snapshot()
        self.assertGreater(s["cpu_cores"], 0)
        self.assertGreater(s["ram_total"], 0)
        self.assertGreater(s["disk_total"], 0)
    def test_human(self):
        self.assertEqual(sysinfo.human(1024), "1.0 KB")
if __name__ == "__main__":
    unittest.main()
