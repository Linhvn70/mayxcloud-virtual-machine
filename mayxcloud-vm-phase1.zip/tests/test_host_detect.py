import sys, os, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.host_detect import classify_windows, choose_accel, HostInfo

class T(unittest.TestCase):
    def test_server_builds(self):
        cases = [(9200, "Windows Server 2012", "experimental"),
                 (9600, "Windows Server 2012 R2", "experimental"),
                 (14393, "Windows Server 2016", "untested"),
                 (17763, "Windows Server 2019", "untested"),
                 (20348, "Windows Server 2022", "untested"),
                 (26100, "Windows Server 2025", "untested")]
        for b, n, t in cases:
            self.assertEqual(classify_windows(b, "Server"), (True, n, t))
    def test_client_same_build_not_server(self):
        self.assertFalse(classify_windows(26100, "Client")[0])
        self.assertEqual(classify_windows(22631, "Client")[1], "Windows 11")
    def test_unknown_server(self):
        self.assertEqual(classify_windows(12345, "Server")[2], "unsupported")
    def test_accel(self):
        self.assertEqual(choose_accel(HostInfo("linux", kvm_access=True))[0], "kvm")
        self.assertEqual(choose_accel(HostInfo("linux", kvm_access=False))[0], "tcg")
        self.assertEqual(choose_accel(HostInfo("windows", cpu_virt=True, hypervisor_present=True))[0], "whpx")
        self.assertEqual(choose_accel(HostInfo("windows", cpu_virt=True, hypervisor_present=False))[0], "tcg")
        self.assertEqual(choose_accel(HostInfo("windows", cpu_virt=False))[0], "tcg")

if __name__ == "__main__":
    unittest.main()
