from __future__ import annotations
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QListWidget,
                               QStackedWidget, QLabel, QGridLayout, QFrame, QPlainTextEdit)
from core.host_detect import detect_host, choose_accel
from core import sysinfo

STYLE = """
QMainWindow, QWidget { background: #ffffff; color: #0b2a55; font-size: 14px; }
QListWidget { background: #0b3d91; color: white; border: none; padding-top: 12px; font-size: 15px; }
QListWidget::item { padding: 12px 18px; }
QListWidget::item:selected { background: #1e6fd9; }
QLabel#title { font-size: 22px; font-weight: bold; color: #0b3d91; }
QFrame#card { background: #eaf2ff; border: 1px solid #c4d9fb; border-radius: 10px; }
QLabel#cardTitle { color: #3a5f99; font-size: 12px; }
QLabel#cardValue { font-size: 18px; font-weight: bold; color: #0b3d91; }
"""


class Card(QFrame):
    def __init__(self, title: str):
        super().__init__()
        self.setObjectName("card")
        lay = QVBoxLayout(self)
        t = QLabel(title); t.setObjectName("cardTitle")
        self.v = QLabel("-"); self.v.setObjectName("cardValue"); self.v.setWordWrap(True)
        lay.addWidget(t); lay.addWidget(self.v)

    def set(self, text: str):
        self.v.setText(text)


class Dashboard(QWidget):
    def __init__(self):
        super().__init__()
        lay = QVBoxLayout(self)
        title = QLabel("Dashboard"); title.setObjectName("title")
        lay.addWidget(title)
        grid = QGridLayout(); lay.addLayout(grid); lay.addStretch()
        names = ["Host OS", "Support level", "Acceleration", "CPU", "RAM", "Disk", "QEMU", "Virtual machines"]
        self.cards = {n: Card(n) for n in names}
        for i, n in enumerate(names):
            grid.addWidget(self.cards[n], i // 2, i % 2)
        self.refresh(first=True)
        self.timer = QTimer(self); self.timer.timeout.connect(self.refresh); self.timer.start(3000)

    def refresh(self, first=False):
        c = self.cards
        if first:
            self.host = detect_host()
            accel, why = choose_accel(self.host)
            c["Host OS"].set(f"{self.host.os_name} ({self.host.arch})" + (" - Server" if self.host.is_server else ""))
            c["Support level"].set(self.host.support_tier)
            c["Acceleration"].set(f"{accel.upper()} - {why}")
        s = sysinfo.snapshot()
        c["CPU"].set(f"{s['cpu_cores']} threads, {s['cpu_percent']:.0f}% in use")
        c["RAM"].set(f"{sysinfo.human(s['ram_used'])} / {sysinfo.human(s['ram_total'])}")
        c["Disk"].set(f"{sysinfo.human(s['disk_free'])} free of {sysinfo.human(s['disk_total'])}")
        c["QEMU"].set(f"{s['qemu_version']}\n{s['qemu_path']}" if s["qemu_path"] else "NOT FOUND - install QEMU")
        c["Virtual machines"].set("0 (VM creation not implemented yet)")


class HostPage(QWidget):
    def __init__(self):
        super().__init__()
        lay = QVBoxLayout(self)
        t = QLabel("About"); t.setObjectName("title"); lay.addWidget(t)
        box = QPlainTextEdit(); box.setReadOnly(True); lay.addWidget(box)
        h = detect_host()
        box.setPlainText(
            "MâyXCloud Virtual Machine (MXVM)\n\nHost details:\n" +
            "\n".join(f"  {k}: {v}" for k, v in h.__dict__.items()) +
            f"\n\nData folder: {sysinfo.data_dir()}\n\nStatus: development build. "
            "Implemented: host detection, Dashboard. Not implemented yet: creating and running VMs.")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MâyXCloud Virtual Machine")
        self.resize(1000, 620)
        self.setStyleSheet(STYLE)
        root = QWidget(); self.setCentralWidget(root)
        lay = QHBoxLayout(root); lay.setContentsMargins(0, 0, 0, 0)
        self.nav = QListWidget(); self.nav.setFixedWidth(200)
        self.stack = QStackedWidget()
        for name, page in (("Dashboard", Dashboard()), ("About", HostPage())):
            self.nav.addItem(name); self.stack.addWidget(page)
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)
        lay.addWidget(self.nav); lay.addWidget(self.stack, 1)
