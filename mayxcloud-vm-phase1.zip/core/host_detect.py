"""Host detection for MXVM (Windows, Windows Server, Linux). Read-only: never changes system config."""
from __future__ import annotations
import os, platform, subprocess
from dataclasses import dataclass, field

# build -> (name, support tier). Tier stays "untested" until verified on real hosts.
WINSERVER_BUILDS = {
    9200: ("Windows Server 2012", "experimental"),
    9600: ("Windows Server 2012 R2", "experimental"),
    14393: ("Windows Server 2016", "untested"),
    17763: ("Windows Server 2019", "untested"),
    20348: ("Windows Server 2022", "untested"),
    26100: ("Windows Server 2025", "untested"),
}
# Move a version name here only after it was really tested.
OFFICIALLY_TESTED: set[str] = set()


@dataclass
class HostInfo:
    system: str                    # "windows" | "linux" | "other"
    is_server: bool = False
    os_name: str = ""
    build: int = 0
    arch: str = ""
    cpu_virt: bool | None = None   # VT-x/AMD-V (None = unknown)
    hypervisor_present: bool | None = None
    kvm_access: bool | None = None
    support_tier: str = "unknown"  # official | experimental | untested | unsupported
    notes: list[str] = field(default_factory=list)


def _run_ps(cmd: str) -> str:
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", cmd],
                             capture_output=True, text=True, timeout=20)
        return out.stdout.strip()
    except Exception:
        return ""


def _win_install_type() -> str:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SOFTWARE\Microsoft\Windows NT\CurrentVersion") as k:
            return winreg.QueryValueEx(k, "InstallationType")[0]
    except Exception:
        return ""


def classify_windows(build: int, install_type: str) -> tuple[bool, str, str]:
    """Pure: returns (is_server, os_name, tier)."""
    if install_type.lower() == "server":
        name, tier = WINSERVER_BUILDS.get(build, (f"Windows Server (build {build})", "unsupported"))
        if name in OFFICIALLY_TESTED:
            tier = "official"
        return True, name, tier
    if build >= 22000:
        return False, "Windows 11", "untested"
    if build >= 10240:
        return False, "Windows 10", "untested"
    return False, f"Windows (build {build})", "unsupported"


def choose_accel(h: HostInfo) -> tuple[str, str]:
    """Pure: returns (qemu accel, reason). Never enables any feature."""
    if h.system == "linux":
        if h.kvm_access:
            return "kvm", "KVM available"
        return "tcg", "No access to /dev/kvm; software emulation"
    if h.system == "windows":
        if h.cpu_virt and h.hypervisor_present:
            return "whpx", "Windows Hypervisor Platform available"
        if h.cpu_virt is False:
            return "tcg", "CPU virtualization disabled/unavailable; software emulation"
        return "tcg", "WHPX not confirmed; software emulation (Hyper-V/WHP is never enabled automatically)"
    return "tcg", "Unknown host; software emulation"


def detect_linux() -> HostInfo:
    h = HostInfo(system="linux", os_name=platform.platform(), arch=platform.machine())
    try:
        flags = open("/proc/cpuinfo").read()
        h.cpu_virt = (" vmx" in flags) or (" svm" in flags)
    except OSError:
        pass
    h.kvm_access = os.path.exists("/dev/kvm") and os.access("/dev/kvm", os.R_OK | os.W_OK)
    if os.path.exists("/dev/kvm") and not h.kvm_access:
        h.notes.append("/dev/kvm exists but current user lacks access (add user to 'kvm' group).")
    h.support_tier = "untested"
    return h


def detect_windows(build: int | None = None, install_type: str | None = None) -> HostInfo:
    if build is None:
        try:
            build = int(platform.version().split(".")[-1])
        except ValueError:
            build = 0
    if install_type is None:
        install_type = _win_install_type()
    is_server, name, tier = classify_windows(build, install_type)
    h = HostInfo(system="windows", is_server=is_server, os_name=name, build=build,
                 arch=platform.machine(), support_tier=tier)
    h.cpu_virt = {"True": True, "False": False}.get(
        _run_ps("(Get-CimInstance Win32_Processor).VirtualizationFirmwareEnabled"))
    h.hypervisor_present = {"True": True, "False": False}.get(
        _run_ps("(Get-CimInstance Win32_ComputerSystem).HypervisorPresent"))
    if h.hypervisor_present is False:
        h.notes.append("Hypervisor/WHP not active. Enabling it needs administrator consent; MXVM will not change it.")
    return h


def detect_host() -> HostInfo:
    s = platform.system().lower()
    if s == "windows":
        return detect_windows()
    if s == "linux":
        return detect_linux()
    return HostInfo(system="other", os_name=platform.platform(), arch=platform.machine(),
                    support_tier="unsupported")
