"""Real system information for the Dashboard (no fake values)."""
from __future__ import annotations
import os, shutil, sys, subprocess
from pathlib import Path
import psutil


def find_qemu() -> Path | None:
    exe = "qemu-system-x86_64" + (".exe" if os.name == "nt" else "")
    cands = []
    base = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent.parent
    cands.append(base / "qemu" / exe)
    if os.name == "nt":
        cands += [Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "qemu" / exe]
    w = shutil.which(exe)
    if w:
        cands.append(Path(w))
    return next((c for c in cands if c.is_file()), None)


def qemu_version(path: Path) -> str:
    try:
        out = subprocess.run([str(path), "--version"], capture_output=True, text=True, timeout=10)
        return out.stdout.splitlines()[0] if out.stdout else "unknown"
    except Exception as e:
        return f"error: {e}"


def data_dir() -> Path:
    base = os.environ.get("APPDATA") if os.name == "nt" else os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local/share"))
    p = Path(base) / "MayXCloudVM"
    p.mkdir(parents=True, exist_ok=True)
    return p


def snapshot() -> dict:
    vm = psutil.virtual_memory()
    root = Path(data_dir().anchor or "/")
    du = shutil.disk_usage(root)
    q = find_qemu()
    return {
        "cpu_cores": psutil.cpu_count(logical=True),
        "cpu_percent": psutil.cpu_percent(interval=0.2),
        "ram_total": vm.total, "ram_used": vm.used,
        "disk_total": du.total, "disk_free": du.free,
        "qemu_path": str(q) if q else None,
        "qemu_version": qemu_version(q) if q else None,
        "data_dir": str(data_dir()),
    }


def human(n: float) -> str:
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} PB"
